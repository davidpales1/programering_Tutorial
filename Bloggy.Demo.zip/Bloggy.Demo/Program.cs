﻿
namespace Bloggy.Demo
{
    class Program
    {
        static void Main()
        {
            var app = new App();
            app.Run();
        }
    }
}
