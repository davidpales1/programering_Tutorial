﻿
USE BlogPostDemo

SELECT * FROM BlogPost